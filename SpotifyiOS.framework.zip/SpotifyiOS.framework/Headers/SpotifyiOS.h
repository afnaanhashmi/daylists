#ifndef _SPOTIFYIOS_
#define _SPOTIFYIOS_

#import "SpotifyAppRemote.h"
#import "SPTLogin.h"

#endif /* _SPOTIFYIOS_ */
